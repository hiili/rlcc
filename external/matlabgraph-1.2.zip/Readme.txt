To install just un zip and add the folder to the path. There are several examples and demos.

Please contact me with error and comments

Thomas F Rathbun
tom.rathbun@usafa.af.mil